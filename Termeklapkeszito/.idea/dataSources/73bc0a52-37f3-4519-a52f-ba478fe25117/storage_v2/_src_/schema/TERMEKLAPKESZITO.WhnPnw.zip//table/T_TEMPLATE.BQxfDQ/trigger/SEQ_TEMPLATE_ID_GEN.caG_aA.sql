CREATE TRIGGER SEQ_TEMPLATE_ID_GEN
  BEFORE INSERT
  ON T_TEMPLATE
  FOR EACH ROW
  begin
    if inserting then
      if :NEW."TEMPLATE_ID" is null then
        select SEQ_TEMPLATE_ID.nextval into :NEW."TEMPLATE_ID" from dual;
      end if;
    end if;
  end;
/

