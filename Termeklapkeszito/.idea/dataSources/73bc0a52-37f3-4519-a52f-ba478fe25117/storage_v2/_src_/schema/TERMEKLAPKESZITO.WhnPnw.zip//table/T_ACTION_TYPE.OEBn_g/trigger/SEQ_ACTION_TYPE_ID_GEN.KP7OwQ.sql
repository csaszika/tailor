CREATE TRIGGER SEQ_ACTION_TYPE_ID_GEN
  BEFORE INSERT
  ON T_ACTION_TYPE
  FOR EACH ROW
  begin
    if inserting then
      if :NEW."ACTION_TYPE_ID" is null then
        select SEQ_ACTION_TYPE_ID.nextval into :NEW."ACTION_TYPE_ID" from dual;
      end if;
    end if;
  end;
/

