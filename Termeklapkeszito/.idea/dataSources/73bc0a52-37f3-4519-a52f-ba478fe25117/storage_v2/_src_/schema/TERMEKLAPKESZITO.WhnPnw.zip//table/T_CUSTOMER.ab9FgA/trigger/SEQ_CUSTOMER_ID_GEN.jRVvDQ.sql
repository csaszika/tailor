CREATE TRIGGER SEQ_CUSTOMER_ID_GEN
  BEFORE INSERT
  ON T_CUSTOMER
  FOR EACH ROW
  begin
    if inserting then
      if :NEW."CUSTOMER_ID" is null then
        select SEQ_CUSTOMER_ID.nextval into :NEW."CUSTOMER_ID" from dual;
      end if;
    end if;
  end;
/

