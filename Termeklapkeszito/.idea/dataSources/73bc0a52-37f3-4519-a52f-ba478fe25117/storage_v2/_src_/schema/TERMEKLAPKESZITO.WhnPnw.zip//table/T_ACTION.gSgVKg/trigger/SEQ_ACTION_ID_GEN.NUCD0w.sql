CREATE TRIGGER SEQ_ACTION_ID_GEN
  BEFORE INSERT
  ON T_ACTION
  FOR EACH ROW
  begin
    if inserting then
      if :NEW."ACTION_ID" is null then
        select SEQ_ACTION_ID.nextval into :NEW."ACTION_ID" from dual;
      end if;
    end if;
  end;
/

